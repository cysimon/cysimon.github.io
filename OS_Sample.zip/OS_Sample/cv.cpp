// EECS 482 Project 2
// chenyis, fuhu, linjn
#include "impl.h"

using namespace std;

cv::cv() {
    impl_ptr = new impl();
}

cv::~cv() {
    delete impl_ptr;
}

void cv::wait(mutex& mtx){
    assert_interrupts_enabled();
    cpu::interrupt_disable();
    assert_interrupts_disabled();

    // Current thread unlock
    mtx.impl_ptr->unlock_helper();

    // Wait for signal
    impl_ptr->cv_waiting_queue.push(cpu::self()->impl_ptr->curr_tcb_ptr);
    cpu::impl::switch_to_next();

    // Get lock
    mtx.impl_ptr->lock_helper();

    assert_interrupts_disabled();
    cpu::interrupt_enable();
    assert_interrupts_enabled();
}

void cv::signal() {
    assert_interrupts_enabled();
    cpu::interrupt_disable();
    assert_interrupts_disabled();

    if(!impl_ptr->cv_waiting_queue.empty()){
        impl_ptr->signal_helper();
    }
    
    assert_interrupts_disabled();
    cpu::interrupt_enable();
    assert_interrupts_enabled();
}

void cv::broadcast() {
    assert_interrupts_enabled();
    cpu::interrupt_disable();
    assert_interrupts_disabled();

    while(!impl_ptr->cv_waiting_queue.empty()){
        impl_ptr->signal_helper();
    }

    assert_interrupts_disabled();
    cpu::interrupt_enable();
    assert_interrupts_enabled();
}