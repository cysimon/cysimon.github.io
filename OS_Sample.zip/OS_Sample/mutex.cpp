// EECS 482 Project 2
// chenyis, fuhu, linjn
#include "impl.h"

using namespace std;

mutex::mutex() {
    impl_ptr = new impl();
}

mutex::~mutex() {
    delete impl_ptr;
}

void mutex::lock() {
    assert_interrupts_enabled();
    cpu::interrupt_disable();
    assert_interrupts_disabled();

    impl_ptr->lock_helper();
    
    assert_interrupts_disabled();
    cpu::interrupt_enable();
    assert_interrupts_enabled();
}

void mutex::unlock() {
    assert_interrupts_enabled();
    cpu::interrupt_disable();
    assert_interrupts_disabled();

    impl_ptr->unlock_helper();

    assert_interrupts_disabled();
    cpu::interrupt_enable();
    assert_interrupts_enabled();
}