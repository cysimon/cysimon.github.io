// EECS 482 Project 2
// chenyis, fuhu, linjn
#include "impl.h"

using namespace std;

uint64_t TCB::context_counter = 1;

void cpu::init(thread_startfunc_t func, void *arg)
{
    // If no func is passed in, suspend
    if(!func) interrupt_enable_suspend();

    try {
        impl_ptr = new impl();

        // New os_tcb_ptr
        impl_ptr->os_tcb_ptr = new TCB();
        
        // Populate interrupt table
        interrupt_vector_table[TIMER] = &impl::timer_handler;

        TCB *tcb_ptr = new TCB();
        makecontext(tcb_ptr->context_ptr, (void (*)()) & thread::impl::thread_func, 3, func, arg, nullptr);

        // Push parent thread to ready_queue;
        impl_ptr->ready_queue.push(tcb_ptr);
    }
    catch (std::bad_alloc) {
        throw std::bad_alloc();
    }
    
    // Run the first thread
    while(1) {
        while(!impl_ptr->ready_queue.empty()) {
            //impl_ptr->curr_context_ptr = impl_ptr->ready_queue.front();
            impl_ptr->curr_tcb_ptr = impl_ptr->ready_queue.front();
            impl_ptr->ready_queue.pop();
            swapcontext(impl_ptr->os_tcb_ptr->context_ptr, impl_ptr->curr_tcb_ptr->context_ptr);
            while (!cpu::self()->impl_ptr->finish_queue.empty()) {
                cpu::self()->impl_ptr->delete_tcb(cpu::self()->impl_ptr->finish_queue.front());
                cpu::self()->impl_ptr->finish_queue.pop();
            }
        }

        // Suspend CPU when there are no runnable threads
        cpu::interrupt_enable_suspend();
        // For single cpu - "init() never return"
        assert(0);
    }
}