// EECS 482 Project 2
// chenyis, fuhu, linjn
#include "impl.h"

using namespace std;

thread::thread(thread_startfunc_t func, void * arg)
{
    assert_interrupts_enabled();
    cpu::interrupt_disable();
    assert_interrupts_disabled();

    // Sanity check
    if (!func) {
        assert_interrupts_disabled();
        cpu::interrupt_enable();
        assert_interrupts_enabled();
        throw std::runtime_error("Invalid func");
    }

    // Handling resource exhaustion
    try{
        impl_ptr = new impl();

        // Allocate TCB
        TCB *tcb_ptr = new TCB();
        makecontext(tcb_ptr->context_ptr, (void (*)())&thread::impl::thread_func, 3, func, arg, this->impl_ptr);

        // Add TCB to ready queue
        cpu::self()->impl_ptr->ready_queue.push(tcb_ptr);
    }
    catch(std::bad_alloc) {
        assert_interrupts_disabled();
        cpu::interrupt_enable();
        assert_interrupts_enabled();
        throw std::bad_alloc();
    }

    assert_interrupts_disabled();
    cpu::interrupt_enable();
    assert_interrupts_enabled();
}

thread::~thread(){
    if (impl_ptr->can_delete_impl_ptr){
        delete impl_ptr;
    } else {
        impl_ptr->can_delete_impl_ptr = true;
    }
}

void thread::join() {
    assert_interrupts_enabled();
    cpu::interrupt_disable();
    assert_interrupts_disabled();

    // Do nothing if thread has finished. Otherwise, wait until it finishes
    if (!(impl_ptr->finish_flag))
    {
        impl_ptr->join_queue.push(cpu::self()->impl_ptr->curr_tcb_ptr);
        cpu::impl::switch_to_next();
    }
    
    assert_interrupts_disabled();
    cpu::interrupt_enable();
    assert_interrupts_enabled();
}

void thread::yield() {
    assert_interrupts_enabled();
    cpu::interrupt_disable();
    assert_interrupts_disabled();

    if (!cpu::self()->impl_ptr->ready_queue.empty()) {
        cpu::self()->impl_ptr->ready_queue.push(cpu::self()->impl_ptr->curr_tcb_ptr);
        cpu::impl::switch_to_next();
    }
    
    assert_interrupts_disabled();
    cpu::interrupt_enable();
    assert_interrupts_enabled();
}