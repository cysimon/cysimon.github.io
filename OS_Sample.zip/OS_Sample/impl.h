// EECS 482 Project 2
// chenyis, fuhu, linjn
#ifndef _IMPL_H
#define _IMPL_H

#include "cpu.h"
#include "cv.h"
#include "mutex.h"
#include "thread.h"
#include <cassert>
#include <iostream>
#include <queue>
#include <ucontext.h>
#include <new>

using namespace std;

class TCB
{
public:
    TCB() {
        context_ptr = new ucontext_t();
        getcontext(context_ptr);
        id = context_counter++;
        original_stack = new char[STACK_SIZE];
        context_ptr->uc_stack.ss_sp = original_stack;
        context_ptr->uc_stack.ss_size = STACK_SIZE;
        context_ptr->uc_stack.ss_flags = 0;
        context_ptr->uc_link = nullptr;
    }

    ~TCB() {
        delete[] original_stack;
        delete context_ptr;
    }

    ucontext_t *context_ptr;
    uint64_t id;
    char* original_stack;
    static uint64_t context_counter;
};

class cpu::impl
{
public:
    impl() : curr_tcb_ptr(nullptr), os_tcb_ptr(nullptr) {} // cpu impl ctor
    queue<TCB *> finish_queue; // The threads that have finished and are to be deleted.
    queue<TCB *> ready_queue; // The threads waiting to be scheduled
    TCB *curr_tcb_ptr; // The current thread that CPU is running
    TCB *os_tcb_ptr; // The "cleaner" thread. It is what it is :)

    static void switch_to_os(){
        assert_interrupts_disabled();
        cpu::self()->impl_ptr->curr_tcb_ptr = cpu::self()->impl_ptr->os_tcb_ptr;
        setcontext(cpu::self()->impl_ptr->os_tcb_ptr->context_ptr);
    }

    static void switch_to_next(){
        if (cpu::self()->impl_ptr->ready_queue.empty()){
            switch_to_os();
        } else {
            TCB *curr_tcb_ptr_local = cpu::self()->impl_ptr->curr_tcb_ptr;
            cpu::self()->impl_ptr->curr_tcb_ptr = cpu::self()->impl_ptr->ready_queue.front();
            cpu::self()->impl_ptr->ready_queue.pop();
            assert_interrupts_disabled();
            swapcontext(curr_tcb_ptr_local->context_ptr, cpu::self()->impl_ptr->curr_tcb_ptr->context_ptr);
            assert_interrupts_disabled();
            while (!cpu::self()->impl_ptr->finish_queue.empty()) {
                cpu::self()->impl_ptr->delete_tcb(cpu::self()->impl_ptr->finish_queue.front());
                cpu::self()->impl_ptr->finish_queue.pop();
            }
        }
    }

    void delete_tcb(TCB * tcb_to_delete)
    {
        delete tcb_to_delete;
    }

    static void timer_handler() {
        assert_interrupts_enabled();
        interrupt_disable();
        assert_interrupts_disabled();

        if (!cpu::self()->impl_ptr->ready_queue.empty()) {
            cpu::self()->impl_ptr->ready_queue.push(cpu::self()->impl_ptr->curr_tcb_ptr);
            cpu::impl::switch_to_next();
        }

        assert_interrupts_disabled();
        interrupt_enable();
        assert_interrupts_enabled();
    }
};

class thread::impl
{
public:
    impl() : finish_flag(false), can_delete_impl_ptr(false) {}

    queue<TCB *> join_queue; // To store the threads waiting for this thread to finish
    bool finish_flag; // If true, the thread finished execution; if false, not finished yet
    bool can_delete_impl_ptr; // Used in join()

    static void thread_func(thread_startfunc_t func, void *arg, thread::impl *thread_impl_ptr)
    {
        // OS code
        while (!cpu::self()->impl_ptr->finish_queue.empty()) {
            cpu::self()->impl_ptr->delete_tcb(cpu::self()->impl_ptr->finish_queue.front());
            cpu::self()->impl_ptr->finish_queue.pop();
        }
        
        // Enable interrupts before running user code
        assert_interrupts_disabled();
        cpu::interrupt_enable();
        assert_interrupts_enabled();

        // User code starts
        (*func)(arg);
        
        // OS code
        assert_interrupts_enabled();
        cpu::interrupt_disable();
        assert_interrupts_disabled();

        // Check if this thread called join()
        if(thread_impl_ptr != nullptr){
            thread_impl_ptr->finish_flag = true;
            while (!thread_impl_ptr->join_queue.empty())
            {
                TCB *waiting_join_queue_context = thread_impl_ptr->join_queue.front();
                thread_impl_ptr->join_queue.pop();
                cpu::self()->impl_ptr->ready_queue.push(waiting_join_queue_context);
            }

            if (thread_impl_ptr->can_delete_impl_ptr){
                delete thread_impl_ptr;
            } else {
                thread_impl_ptr->can_delete_impl_ptr = true;
            }
        }

        // Deallocate the resources of this thread - give control back to cpu (os_context)
        cpu::self()->impl_ptr->finish_queue.push(cpu::self()->impl_ptr->curr_tcb_ptr);
        cpu::impl::switch_to_next();
        assert(0);
    };
};

class mutex::impl
{
public:
    impl() : locked(false), lock_holder(0) {}

    queue<TCB *> lock_waiting_queue; // The threads waiting for the lock
    bool locked; // If true, lock is acquired by someone; if false, lock is free
    uint64_t lock_holder; // The thread that is holding the lock
    
    void lock_helper() {
        if (locked) {
            // Add the thread called lock() to lock waiting queue
            lock_waiting_queue.push(cpu::self()->impl_ptr->curr_tcb_ptr);
            cpu::impl::switch_to_next();
        } else {
            locked = true;
        }
        lock_holder = cpu::self()->impl_ptr->curr_tcb_ptr->id;
    }

    void unlock_helper() {
        // 1. Check lock holder
        if (!locked){
            assert_interrupts_disabled();
            cpu::interrupt_enable();
            assert_interrupts_enabled();
            throw std::runtime_error("Lock is not locked");
        }
        if (lock_holder != cpu::self()->impl_ptr->curr_tcb_ptr->id) {
            assert_interrupts_disabled();
            cpu::interrupt_enable();
            assert_interrupts_enabled();
            throw std::runtime_error("User is unlocking a thread with no lock");
        }
        // 2. Unlock
        // If any thread is waiting for the lock, move the waiting thread to ready queue
        locked = false;
        lock_holder = 0;
        if (!lock_waiting_queue.empty()){
            TCB *next_tcb_ptr_to_ready = lock_waiting_queue.front();
            lock_waiting_queue.pop();
            cpu::self()->impl_ptr->ready_queue.push(next_tcb_ptr_to_ready);
            locked = true;
        }
    }
};

class cv::impl
{
public:
    impl() {}

    queue<TCB *> cv_waiting_queue;//The threads that are sleeping

    void signal_helper() {
        TCB *next_tcb_ptr_to_ready = cv_waiting_queue.front();
        cv_waiting_queue.pop();
        cpu::self()->impl_ptr->ready_queue.push(next_tcb_ptr_to_ready);
    }
};

#endif