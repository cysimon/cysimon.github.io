This code sample includes some significant components of operating system,
including implementations of mutex, condition variable, a simple cpu, and threading library.
All header(.h) files (except impl.h, which is implemented by me and my teammates), 
are provided under EECS 482: Operating system at the University of Michigan.
