﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PolaroidGameHandler : MonoBehaviour
{

    public PlayerState playerState;
    public GameObject player;
    public ScreenshotHandler screenshotHandler;

    public Inventory inventory;
    public Animator shutterAnimator;
    public Camera mainCamera;

    private float lastLeftClickTime;
    public const float leftClickBufferTime = 0.75f;

    // @Frank: photo_number to track photos
    int currentPhotoIndex = 0;

    bool isDisplaying = false;

    // @Chen: The pressing time needed to delete a photo
    public float pressingTimeToDelete = 1.5f;
    private bool E_held = false;
    private float timeSinceEHold = 0f;
    private bool hasDeleted = false;
    private bool inTeleportation = false;

    private float cameraInitFOV;

    public float cameraTargetFOV = 90f;
    public float teleportDuration = 0.3f;

    public void setIsDisplaying(bool input)
    {
        isDisplaying = input;
    }
    public bool getIsDisplaying()
    {
        return isDisplaying;
    }
    // Start is called before the first frame update
    void Start()
    {
        cameraInitFOV = mainCamera.fieldOfView;
    }

    // Update is called once per frame
    void Update()
    {
        // Left click to take a photo
        if (Input.GetMouseButtonDown(0) && PlayerState.instance.polaroidOpened && (Time.time - lastLeftClickTime) > leftClickBufferTime)
        {
            //Debug.Log("Left clicked");
            lastLeftClickTime = Time.time;
            // Flash effect (ln 36, 37) added by Chenlaoshi:
            // Note: Please deploy Prefabs-UI to the scene
            EventBus.Publish<InstantScreenEvent>(new InstantScreenEvent(false));
            EventBus.Publish<FadeScreenEvent>(new FadeScreenEvent(false, true, 1.8f));
            screenshotHandler.TakeScreenshot(Screen.width, Screen.height);
        }

        // else if (Input.GetKeyDown(KeyCode.E) && isDisplaying) {
        // Press E to teleport. Hold E to delete photos
        // @Chen: Both actions should be triggered only when the transition photo is not opened AND polaroid is not opened
        else if (Input.GetKeyDown(KeyCode.E) && !PlayerState.instance.isTransitionPhotoOpened && !PlayerState.instance.polaroidOpened)
        {
            E_held = false;
            timeSinceEHold = Time.timeSinceLevelLoad;
        }
        else if (Input.GetKeyUp(KeyCode.E) && !PlayerState.instance.isTransitionPhotoOpened && !PlayerState.instance.polaroidOpened)
        {
            // Can delete next photo
            hasDeleted = false;

            if (!E_held)
            {
                EventBus.Publish<DeleteUIEvent>(new DeleteUIEvent(false, pressingTimeToDelete * 0.8f));
                if (Time.timeSinceLevelLoad - timeSinceEHold <= pressingTimeToDelete * 0.2)
                {
                    // Trigger a teleportation event
                    if (!inTeleportation && PlayerState.instance.teleportEnabled)
                    {
                        StartCoroutine(TeleportEffect());
                    }
                }
            }
        }
        else if (Input.GetKey(KeyCode.E) && !PlayerState.instance.isTransitionPhotoOpened && !PlayerState.instance.polaroidOpened)
        {
            // Count down
            if (Time.timeSinceLevelLoad - timeSinceEHold >= pressingTimeToDelete * 0.2f && !hasDeleted && inventory.GetTakenPhotoCount() > 1 && !(inventory.GetCurrentPhotoInInventory() is LevelTransitionPhoto)) EventBus.Publish<DeleteUIEvent>(new DeleteUIEvent(true, pressingTimeToDelete * 0.8f));
            if (Time.timeSinceLevelLoad - timeSinceEHold >= pressingTimeToDelete)
            {
                E_held = true;
                if (!hasDeleted)
                {
                    // Prevent multiple deletion
                    hasDeleted = true;

                    // Delete photo codes go here
                    EventBus.Publish<DeleteUIEvent>(new DeleteUIEvent(false, pressingTimeToDelete * 0.8f));
                    inventory.DeleteCurrentPhotoInInventory();
                }
            }
        }

        // Press R to reset objects
        // @Chen: Reset should be triggered only when the player hasn't win
        else if (Input.GetKeyDown(KeyCode.R) && !PlayerState.instance.hasWinned)
        {
            //Might need to publish a resetitemevent
            EventBus.Publish<PhotoResetEvent>(new PhotoResetEvent());
            if (inventory.GetCurrentPhotoInInventory() != null)
                inventory.GetCurrentPhotoInInventory().ObjectReset();
        }

        // Scroll up/down to switch photos
        else if (Input.GetAxis("Mouse ScrollWheel") > 0f && !PlayerState.instance.isPausing)
        {
            // shutterAnimator.Play("ShutterSpinCounterClockwise");
            EventBus.Publish<PlayerInputEvent>(new PlayerInputEvent(PlayerInputType.NextPhoto));
        }
        else if (Input.GetAxis("Mouse ScrollWheel") < 0f && !PlayerState.instance.isPausing)
        {
            // shutterAnimator.Play("ShutterSpinClockwise");
            EventBus.Publish<PlayerInputEvent>(new PlayerInputEvent(PlayerInputType.PrevPhoto));
        }
    }

    public void setCurrentPhotoIndex(int input)
    {
        currentPhotoIndex = input;
    }

    public int getCurrentPhotoIndex()
    {
        return currentPhotoIndex;
    }

    private IEnumerator TeleportEffect()
    {
        inTeleportation = true;
        PlayerState.instance.interactEnabled = false;
        yield return StartCoroutine(CameraFOVZoom(mainCamera, teleportDuration / 2f, true));
        EventBus.Publish<PhotoTeleportEvent>(new PhotoTeleportEvent());
        if (inventory.GetCurrentPhotoInInventory() != null)
            inventory.GetCurrentPhotoInInventory().Reset(player);
        yield return StartCoroutine(CameraFOVZoom(mainCamera, teleportDuration / 2f, false));
        PlayerState.instance.interactEnabled = true;
        inTeleportation = false;
    }

    private IEnumerator CameraFOVZoom(Camera target, float durationSec, bool isZoomIn)
    {
        float initialTime = Time.time;
        // The "progress" variable will go from 0.0f -> 1.0f over the course of "duration_sec" seconds.
        float progress = 0.0f;
        float currentFOV = target.fieldOfView;
        float zoomInIndex = cameraTargetFOV - cameraInitFOV;
        if (!isZoomIn)
        {
            zoomInIndex *= -1;
        }

        while (progress < 1.0f)
        {
            progress = (Time.time - initialTime) / durationSec;
            target.fieldOfView = currentFOV + zoomInIndex * progress;

            yield return null;
        }
        if (isZoomIn) target.fieldOfView = cameraTargetFOV;
        else target.fieldOfView = cameraInitFOV;
    }
}

