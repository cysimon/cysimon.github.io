﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;

public class TransitionPhotoUIController : MonoBehaviour
{
    public Animator animator;
    public GameObject TransitionPhoto;
    public AudioClip audioOnTurn = null;
    public AudioClip audioOnFlip;

    private bool isRotating = false;
    private bool audioPlayed = false;

    private void Start()
    {
        // @Chen: Set PlayerState
        PlayerState.instance.isTransitionPhotoOpened = true;

        PlayerMovement.instance.canMove = false;
        EventBus.Publish(new DisableLookEvent(true));
    }

    private void Update()
    {
        // @Chen: When a transition photo is opened, right click/Esc to close it
        if((Input.GetKeyDown(KeyCode.Mouse1) 
            || Input.GetKeyDown(KeyCode.Escape)) 
            && animator.GetCurrentAnimatorStateInfo(0).IsName("LevelTransitionPhotoFreeze") && PlayerState.instance.isTransitionPhotoOpened)
        {
            // @Chen: Deactivate subtitle. Activate Album UI.
            EventBus.Publish<SubtitleUIEvent>(new SubtitleUIEvent(false));
            EventBus.Publish<AlbumUIEvent>(new AlbumUIEvent(true));

            animator.Play("LevelTransitionPhotoMoveDown");
            StartCoroutine(DisableTransitionUIWithDeplay(1f));
        }

        if(Input.GetKeyDown(KeyCode.Mouse0) 
            && animator.GetCurrentAnimatorStateInfo(0).IsName("LevelTransitionPhotoFreeze")
            && !isRotating)
        {
            if (!audioPlayed && audioOnTurn != null)
            {
                Utils.PlayClipAt(audioOnTurn, Camera.main.transform.position);
                audioPlayed = true;
            }
            Utils.PlayClipAt(audioOnFlip, Camera.main.transform.position);
            StartCoroutine(RotateImage());
        }
    }

    IEnumerator RotateImage()
    {
        isRotating = true;
        Vector3 targetRotation = TransitionPhoto.transform.localRotation.eulerAngles + new Vector3(0, 180, 0);
        yield return StartCoroutine(Utils.RotateObjectOverTime(TransitionPhoto.transform,
                                                               TransitionPhoto.transform.localRotation.eulerAngles,
                                                               targetRotation,
                                                               1f,
                                                               false));
        isRotating = false;
    }

    IEnumerator DisableTransitionUIWithDeplay(float delay)
    {
        yield return new WaitForSeconds(delay);

        PlayerMovement.instance.canMove = true;
        PlayerState.instance.isTransitionPhotoOpened = false;
        EventBus.Publish(new DisableLookEvent(false));
        gameObject.SetActive(false);
    }
}
