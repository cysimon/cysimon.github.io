This code sample includes some important scritps I wrote for the game Polaroid. They carry out important features and gameplay mechanics.
Please check the game Polaroid from my portfolio: https://cysimon.github.io/ or the itch.io page: https://p0tatostudio.itch.io/polaroid
Thank you.