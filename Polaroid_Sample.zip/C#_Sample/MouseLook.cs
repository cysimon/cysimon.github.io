﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This script is used to rotate player's vision by taking mouse input
public class MouseLook : MonoBehaviour
{
    public float mouseSensitivity = 100f;
    public Transform playerBody;
    float xRotation = 0f;

    public bool enableMouseLook = true;

    //Subscription<PauseEvent> pauseSubscription;
    void Start()
    {
        // Lock and hide the mouse cursor
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        //pauseSubscription = EventBus.Subscribe<PauseEvent>(_pauseListener);
        EventBus.Subscribe<DisableLookEvent>(_disableLookListener);

        if (GlobalState.instance != null) mouseSensitivity = GlobalState.instance.settingMouseSensitivity;
    }

    void Update()
    {
        if (enableMouseLook)
        {
            if (GlobalState.instance != null) mouseSensitivity = GlobalState.instance.settingMouseSensitivity;

            float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
            float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

            xRotation -= mouseY;
            xRotation = Mathf.Clamp(xRotation, -90f, 90f);

            transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);

            // Line 30 is used to set player's camera relative movement.
            // Disable it if this script is applied on other cameras that are not binding to a player.
            playerBody.Rotate(Vector3.up * mouseX);
        }
    }

    /*void _pauseListener(PauseEvent event_in)
    {
        if (event_in.on)
        {
            Cursor.visible = true;
            Cursor.lockState = CursorLockMode.None;
            enableMouseLook = false;
        }
        else
        {
            Cursor.visible = false;
            Cursor.lockState = CursorLockMode.Locked;
            enableMouseLook = true;
        }
    }*/

    void _disableLookListener(DisableLookEvent e)
    {
        enableMouseLook = !e.on;
    }
}
