﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.PostProcessing;
using UnityEngine.SceneManagement;

public class PlayerState : MonoBehaviour
{
    // Singleton
    public static PlayerState instance;

    public bool polaroidOpened = false; // Does polaroid view open
    public bool isPausing = false; // Is the game pausing
    public bool isGuidanceOpened = false; // Is the controls panel opening (pause related)
    public bool hasWinned = false; // Has the player winned
    public bool isSettingsOpened = false; // Is the settings panel opening (pause related)
    public bool isTransitionPhotoOpened = false; // Is the player looking at a transition photo
    public bool teleportEnabled = true;
    public bool interactEnabled = true;
    public PostProcessVolume polaroidEffect;

    private bool polaroidEnabled = true;
    void Awake()
    {
        // Singleton
        if (instance == null)
        {
            instance = this;
        }
        else if (instance != this)
        { 
            Destroy(this.gameObject); 
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("scanObjs", 0.0f, 0.5f);
    }

    void scanObjs()
    {
        if (polaroidOpened)
        {
            EventBus.Publish<ScanObjEvent>(new ScanObjEvent(gameObject.transform.GetChild(0).gameObject.GetComponent<Camera>(), false));
        }
    }

    void Update()
    {
        // Hold right click to open polaroid
        if (Input.GetMouseButton(1) && polaroidEnabled)
        {
            // Open polaroid only when:
            // 1. It is not opened yet
            // 2. The player is not looking at a transition photo
            if (!polaroidOpened && !isTransitionPhotoOpened)
            {
                OpenPolaroid();
            }
        }

        // Release right click to close polaroid
        if (!Input.GetMouseButton(1) && polaroidOpened)
        {
            ClosePolaroid();
        }

        // Press Esc to pause or close in-pause menus
        // Only when the player is not looking at a transition photo
        if (Input.GetKeyDown(KeyCode.Escape) && !isTransitionPhotoOpened)
        {
            if (!isPausing)
            {
                PlayerMovement.instance.canMove = false;
                isPausing = true;
                EventBus.Publish<PauseEvent>(new PauseEvent(true));
                Cursor.visible = true;
                Cursor.lockState = CursorLockMode.None;
                EventBus.Publish<DisableLookEvent>(new DisableLookEvent(true));
            }
            else if (isPausing && !isGuidanceOpened && !isSettingsOpened)
            {
                EventBus.Publish<PauseEvent>(new PauseEvent(false));
            }
            else if (isPausing && isGuidanceOpened)
            {
                isGuidanceOpened = false;
                EventBus.Publish<ControlsGuidanceEvent>(new ControlsGuidanceEvent(false));
            }
            else if (isPausing && isSettingsOpened)
            {
                isSettingsOpened = false; 
                EventBus.Publish<ButtonEaseEvent>(new ButtonEaseEvent(true));
                EventBus.Publish<SettingsEvent>(new SettingsEvent(false));
            }
        }
        
        // Press R to restart the game
        // @Matt: Reset functionality added in polaroid game handler
        if (Input.GetKeyDown(KeyCode.R))
        {
            if (hasWinned)
            {
                Cursor.visible = true;
                Cursor.lockState = CursorLockMode.None;
                SceneTransitioner.instance.ChangeScene("MainMenu");
            }
        }

        // Left click to interact with objects
        // Only when the player is not looking at a transition photo
        // @Frank: We should also disable this while pause menu is brought up
        if (Input.GetMouseButtonDown(0) && !polaroidOpened && !isTransitionPhotoOpened && !isPausing)
        {
            EventBus.Publish(new InteractEvent());
        }
    }

    void OpenPolaroid()
    {
        polaroidOpened = true;

        EventBus.Publish<AudioEvent>(new AudioEvent(3));

        // Disable player movement
        PlayerMovement.instance.canMove = false;

        // Fade Screen
        EventBus.Publish<InstantScreenEvent>(new InstantScreenEvent(true));
        EventBus.Publish<FadeScreenEvent>(new FadeScreenEvent(false, true, 1.2f));

        // Modify and post processing
        polaroidEffect.enabled = true;
        EventBus.Publish<MainUIEvent>(new MainUIEvent(false));
        EventBus.Publish<PolaroidUIEvent>(new PolaroidUIEvent(true));

        // Activate polaroid functionality (Done by Frank)
    }

    void ClosePolaroid()
    {
        polaroidOpened = false;

        EventBus.Publish<AudioEvent>(new AudioEvent(3));

        // Enable player movement
        PlayerMovement.instance.canMove = true;

        // Fade Screen
        EventBus.Publish<InstantScreenEvent>(new InstantScreenEvent(true));
        EventBus.Publish<FadeScreenEvent>(new FadeScreenEvent(false, true, 1.2f));

        // Modify UIs and post processing
        polaroidEffect.enabled = false;
        EventBus.Publish<PolaroidUIEvent>(new PolaroidUIEvent(false));
        EventBus.Publish<MainUIEvent>(new MainUIEvent(true));

        EventBus.Publish<ScanObjEvent>(new ScanObjEvent(gameObject.transform.GetChild(0).gameObject.GetComponent<Camera>(), true));

        // Deactivate polaroid functionality (Done by Frank)
    }


    public bool getPolaroidOpened()
    {
        return polaroidOpened;
    }

    static public void disablePolaroid()
    {
        instance.polaroidEnabled = false;
    }

    static public void enablePolaroid()
    {
        instance.polaroidEnabled = true;
    }
}

public class ScanObjEvent
{
    public Camera myCam;
    public bool stopGlow;

    public ScanObjEvent(Camera _myCam, bool _stopGlow) { myCam = _myCam; stopGlow = _stopGlow; }
}

