﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalState : MonoBehaviour
{
    // Singleton
    public static GlobalState instance;

    public float settingMouseSensitivity = 100f;
    public float settingVolume = 100f;
    public float settingSound = 100f;
    public bool enableLogging = false;

    void Start()
    {
        if (instance == null) instance = this;
        else if (instance != this) Destroy(this.gameObject);

        DontDestroyOnLoad(this.gameObject);
    }

    public void OnMouseSensitivityChanged(float value)
    {
        settingMouseSensitivity = value;
    }

    public void OnVolumeChanged(float value)
    {
        settingVolume = value;
    }

    public void OnSoundChanged(float value)
    {
        settingSound = value;
    }

    public void OnLoggingEnabled(bool value)
    {
        enableLogging = value;
    }
}


